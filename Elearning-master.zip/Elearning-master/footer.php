<center>
		<footer>
		
		<p>GNDEC E-Learning Copyright 2015</p>
			<!-- <p>Programmed by: Navdeep CSE A</p> -->
		</footer>
</center>

