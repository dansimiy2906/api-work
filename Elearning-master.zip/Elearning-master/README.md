# Elearning
It is an online learning management system. I have created this project during my six months industrial training.
This project is completely open source and also created using open source technologies.
It mainly contains three modules.
The first module is Admin Module which deals with all the administrative activities. Admin can control all actions of the Learning management system.
Second Module is student module. The registered students can login to see their dashboard. There are some other features available to the students also.
Third module is teacher module.
Teacher can see their student
