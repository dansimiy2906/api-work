<div class="pull-right">
		<footer>
           <p>Programmed by: Navdeep Gurjot CSE A</p>
        <footer>
</div>