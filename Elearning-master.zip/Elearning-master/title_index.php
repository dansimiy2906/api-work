				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/Logo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc">Guru Nanak Dev Engineering College- Ludhiana</p>
							<h3>

							<p> E Learning</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>GNDEC EXCELE:</p>
												<p>Excellence, Competence and Educational</p>
												<p>Leadership in Engineering and Technology</p>
								</div>		
						</div>		
				</div>